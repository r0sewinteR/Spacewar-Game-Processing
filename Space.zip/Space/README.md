# Eunha Storm
A modified version of Galaga, a Japanese arcade game developed and published by Namco. This was a culminating task for Introduction to Computer Science (ICS3U).<br/> <br/>
Programmed using Processing 3 (Java).

## Basic Controls
| Control       | Action        |
| ------------- | ------------- |
| Left Arrow | Move Fighter Left     |
| Right Arrow | Move Fighter Right    |
| Up Arrow | Pause Fighter |
| Left Click | Shoot |
